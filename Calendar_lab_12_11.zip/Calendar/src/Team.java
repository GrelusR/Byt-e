//grupa jast jdentyczna do dru�yny .... ci�ko mi powiedzie� czy nie lepiej by by�o da� im wsp�lnego rodzica czy co� 
// zrobi�em tak �eby nie ctrl+C ctrl+v tu ...

public class Team extends Group {

	public Team(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	public Team(String name, Employee[] members) {
		super(name, members);
		// TODO Auto-generated constructor stub
	}

}
