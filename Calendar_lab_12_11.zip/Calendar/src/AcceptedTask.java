import java.util.Date;

public class AcceptedTask extends Task {

	public AcceptedTask(String n, String d, Date sd, Date ed, boolean m, Employee c) {
		super(n, d, sd, ed, m, c);
	}

}
