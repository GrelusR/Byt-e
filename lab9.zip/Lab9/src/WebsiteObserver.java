import java.io.IOException;
import java.util.Date;

public class WebsiteObserver extends Observer { //Concrete observer

	private String website ;
	private Date last_modified;
	
	public WebsiteObserver(String website,Date current) throws IOException{
		this.website = website;
		this.last_modified = current;
		}
	
	public String getWebsiteUrl(){
		return this.website;
	}
	
	public Date getLastModifiedDate(){
		return last_modified;
	}
	
	@Override
	public void update(String website , Date current_mod) {
		if(this.website.equals(website))
			if(last_modified.before(current_mod)){
				System.out.println("Website modification date of " +website+" has been updated form "+last_modified+" to "+current_mod);
				last_modified = current_mod;
			}
	}
}
