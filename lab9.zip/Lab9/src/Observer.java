import java.util.Date;

public abstract class Observer {
	
	public abstract void update(String website , Date current_mod); 
}
