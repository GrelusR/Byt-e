import static org.junit.Assert.*;

import java.io.IOException;
import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

public class WebsiteWatchdogTest {
	
	WebsiteWatchdog ww;
	WebsiteObserver wo;
	Date testDate;
	String testWebsite;
	
	@Before
	public void setup() throws IOException{
		testWebsite = "www.example.org";
		testDate = new Date();
		ww = new WebsiteWatchdog();
		ww.addWebsite(testWebsite,testDate);
		wo = new WebsiteObserver(testWebsite,testDate);
	}
	
	@Test
	public void checkWebsites(){
		assertEquals(1,ww.getWebsites().size());
		assertTrue(testWebsite.equals(ww.getWebsites().get(0)));
	}
	
	@Test
	public void checkObservers(){
		assertEquals(1,ww.getObservers().size());
		assertTrue(wo.getWebsiteUrl().equals(ww.getObservers().get(0).getWebsiteUrl()));
	}
	
	@Test
	public void checkAddingWebsites() throws IOException{
		String nWebsite = "www.newTestWebsite.com";
		Date nDate = new Date(testDate.getTime()+1000);
		ww.addWebsite(nWebsite, nDate);
		assertEquals(2,ww.getObservers().size());
		assertTrue(nWebsite.equals(ww.getObservers().get(1).getWebsiteUrl()));
		assertTrue(nDate.equals(ww.getObservers().get(1).getLastModifiedDate()));
	}
	
	@Test
	public void checkDeletingWebsites(){
		ww.deleteWebsite(testWebsite);
		assertEquals(0,ww.getObservers().size());
		assertEquals(0,ww.getWebsites().size());
	}
	
	@Test
	public void checkIfObserversRespond(){
		ww.notifyAllObservers(testWebsite, new Date(testDate.getTime()+3600));
	}
	
}
