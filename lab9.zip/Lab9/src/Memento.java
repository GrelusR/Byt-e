import java.util.List;

public class Memento {
	
	private List<WebsiteObserver> observersState;
	private List<String> websitesState;
	
	public Memento(List<String> websites,List<WebsiteObserver> observers){
		this.observersState = observers;
		this.websitesState = websites;
	}
	
	public void setState(List<String> websites,List<WebsiteObserver> observers){
		this.observersState = observers;
		this.websitesState = websites;
	}
	
	public List<String> getStateOfWebsites(){
		return websitesState;
	}
	
	public List<WebsiteObserver> getStateOfObservers(){
		return observersState;
	}
}
