import java.io.IOException;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class WebsiteWatchdog  { //Subject class
	
	private List<WebsiteObserver> watchers ;
	private List<String> websites;
	
	public WebsiteWatchdog(){
		watchers = new ArrayList<WebsiteObserver>();
		websites = new ArrayList<String>();
	}
	
	public void addWebsite(String website_to_watch,Date date) throws IOException{
		if(!websites.contains(website_to_watch)){
			if(date == null){
				Date current = getModification(website_to_watch);
				websites.add(website_to_watch);
				watchers.add(new WebsiteObserver(website_to_watch,current));
				
			}
			else{
				watchers.add(new WebsiteObserver(website_to_watch,date));
				websites.add(website_to_watch);
			}
		}
	}
	
	public void deleteWebsite(String website_to_delete){
		if(this.websites.contains(website_to_delete)){
			this.websites.remove(website_to_delete);
			for(WebsiteObserver wo:this.getObservers()){
				if(wo.getWebsiteUrl().equals(website_to_delete));
				this.watchers.remove(wo);
				break;
			}
		}
	}
	
	public List<WebsiteObserver> getObservers(){
		return watchers;
	}
	
	public List<String> getWebsites(){
		return websites;
	}
	
	public void notifyAllObservers(String website , Date current_mod){
		for(WebsiteObserver w : watchers){
			w.update(website,current_mod);
		}
	}
	
	public void circleThroughWebsites() throws IOException{
		for(String s:websites){
			Date current_mod = getModification(s);
			notifyAllObservers(s,current_mod);
		}
	}
	
	public Memento saveToMemento(){
		return new Memento(this.websites,this.watchers);
	}
	
	public void restoreFromMemento(Memento mem){
		this.websites = mem.getStateOfWebsites();
		this.watchers = mem.getStateOfObservers();
	}
	
	private Date getModification(String website) throws IOException{
		URL address = new URL(website);
		URLConnection connect = address.openConnection();
		long time = connect.getLastModified();
		Date modifiedDate = new Date(time);
		return modifiedDate;
	}

}
