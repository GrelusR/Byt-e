import static org.junit.Assert.*;

import java.io.IOException;
import java.util.Date;

import org.junit.Before;
import org.junit.Test;

public class WebsiteObserverTest {
	
	WebsiteObserver wo;
	String website;
	Date testDate;
	
	@Before
	public void setUp() throws IOException {
		testDate = new Date();
		website = "www.example.org";
		wo = new WebsiteObserver(website,testDate);
	}

	@Test
	public void testUrl(){
		assertEquals(website,wo.getWebsiteUrl());
	}
	
	@Test
	public void testDate(){
		assertEquals(testDate,wo.getLastModifiedDate());
	}
	
	@Test
	public void testReactionToLaterDate() {
		Date nDate = new Date(testDate.getTime()+3600);
		wo.update(website, nDate);
		assertEquals(nDate.getTime(),wo.getLastModifiedDate().getTime());
	}
	
}
