import java.io.IOException;
import java.util.Date;

import org.junit.Before;
import org.junit.Test;

public class MementoTest {
	
	Memento mem;
	WebsiteWatchdog ww;
	String testWebsite;
	Date testDate;
	
	@Before
	public void setup() throws IOException{
		ww = new WebsiteWatchdog();
		testWebsite = "www.example.org";
		testDate = new Date();
		ww.addWebsite(testWebsite, testDate);
		
	}
	
	@Test
	public void checkStateOfWebsites(){
		
	}
	
	@Test
	public void checkStateOfObservers(){
		
	}
}
