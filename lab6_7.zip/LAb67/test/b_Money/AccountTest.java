package b_Money;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class AccountTest {
	Currency SEK, DKK;
	Bank Nordea;
	Bank DanskeBank;
	Bank SweBank;
	Account testAccount;
	
	@Before
	public void setUp() throws Exception { // class Account didnt require any corrections
		SEK = new Currency("SEK", 0.15);
		SweBank = new Bank("SweBank", SEK);
		SweBank.openAccount("Alice");
		testAccount = new Account("Hans", SEK);
		testAccount.deposit(new Money(10000000, SEK)); 

		SweBank.deposit("Alice", new Money(1000000, SEK));
	}
	
	@Test
	public void testAddRemoveTimedPayment() { 
	testAccount.addTimedPayment("timedTest",10,20,new Money(100,SEK),SweBank,"Alice");
	if(!testAccount.timedPaymentExists("timedTest"))
		fail("Timed payment not found or not created");
	testAccount.removeTimedPayment("timedTest");
	if(testAccount.timedPaymentExists("timedTest"))
		fail("timed payment has not been removed");
	}

	@Test
	public void testTimedPayment() throws AccountDoesNotExistException {
		testAccount.addTimedPayment("testOfTheTime",3,1,new Money(100,SEK),SweBank,"Alice");
		testAccount.tick();
		assertEquals((Integer)1000100,SweBank.getBalance("Alice"));
		testAccount.tick();
		testAccount.tick();
		testAccount.tick();
		assertEquals((Integer)1000200,SweBank.getBalance("Alice"));
	}

	@Test
	public void testAddWithdraw() {
		testAccount.deposit(new Money(100,SEK));
		assertEquals((Integer)10000100,testAccount.getBalance().getAmount());
		testAccount.withdraw(new Money(100,SEK));
		assertEquals((Integer)10000000,testAccount.getBalance().getAmount());
	}
	
	@Test
	public void testGetBalance() {
		assertEquals(testAccount.getBalance().getAmount(),(Integer)10000000);
	}
}
