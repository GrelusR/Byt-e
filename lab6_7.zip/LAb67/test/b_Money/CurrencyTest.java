package b_Money;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import com.sun.media.jfxmedia.logging.Logger;

public class CurrencyTest {
	Currency SEK, DKK, NOK, EUR;
	
	@Before
	public void setUp() throws Exception {
		/* Setup currencies with exchange rates */
		SEK = new Currency("SEK", 0.15);
		DKK = new Currency("DKK", 0.20);
		EUR = new Currency("EUR", 1.5);
	}

	@Test
	public void testGetName() {
		assertEquals(SEK.getName(),"SEK");
	}
	
	@Test
	public void testGetRate() {
		if(DKK.getRate() != 0.20)
			fail("wrong rate");
	}
	
	@Test
	public void testSetRate() {
		double new_currency_rate = 1.6;
		EUR.setRate(new_currency_rate);
		if(EUR.getRate() != new_currency_rate)
			fail("wrong rate");
	}
	
	@Test
	public void testGlobalValue() {
		int total_val = (int)(100 * 0.20);
		assertEquals((int)DKK.universalValue(100),total_val);
	}
	
	@Test
	public void testValueInThisCurrency() {
		// 10 SEK == 1 euro 
		
		assertEquals(1,(int)EUR.valueInThisCurrency(10, SEK));
	}

}
