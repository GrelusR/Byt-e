
package src;

import java.util.*;

public class Configuration {
	public int interval;

	public int duration;

	public int departure;

	public void load(Properties props) throws ConfigurationException {
		//String valueString;
		int value;

		value = extractProperty(props, "interval", "monitor interval");
		interval = value;

		value = extractProperty(props,"duration","duration");
		
		if ((value % interval) != 0) {
			throw new ConfigurationException("duration % interval");
		}
		duration = value;

		value = extractProperty(props,"departure","departure offset");
		
		if ((value % interval) != 0) {
			throw new ConfigurationException("departure % interval");
		}
		departure = value;
	}
	//I reduced some repetative code using this method
	private int extractProperty(Properties props, String property_name, String exception_name) throws ConfigurationException {
		String valueString;
		int value;
		//valueString = props.getProperty("interval");
		valueString = props.getProperty(property_name);
		if (valueString == null) {
			//throw new ConfigurationException("monitor interval");
			throw new ConfigurationException(exception_name);
		}
		value = Integer.parseInt(valueString);
		if (value <= 0) {
			throw new ConfigurationException(property_name +" > 0");
		}
		return value;
	}
}



