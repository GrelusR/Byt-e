package src;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class ExpressionTest {

	@Test
	public void testConstant() {
		Expression e = new Expression(-43);
		assertEquals(e.evaluate(), -43);
	}
	@Test
	public void testAddition() {
		Expression e = quickExpression(100, -100, '+');
		assertEquals(e.evaluate(), 0);
	}
	private Expression quickExpression(int left, int right, char operation) { // i have extracted this one and made it more concise without that constant new Expression
		Expression e = new Expression(operation, new Expression(left), new Expression(
				right));
		return e;
	}
	@Test
	public void testSubtraction() {
		Expression e = quickExpression(100,-100,'-');
		assertEquals(e.evaluate(), 200);
	}
	@Test
	public void testMultiplication() {
		Expression e = quickExpression(100,-100,'*');
		assertEquals(e.evaluate(), -10000);
	}
	@Test
	public void testDivision() {
		Expression e = quickExpression(100,-100,'/');
		assertEquals(e.evaluate(), -1);
	}
	@Test
	public void testComplexExpression() {
		// 1+2-3*4/5
		Expression e = new Expression('-', new Expression('+',
				new Expression(1), new Expression(2)), new Expression('/',
				new Expression('*', new Expression(3), new Expression(4)),
				new Expression(5)));
		assertEquals(e.evaluate(), 1);
	}

}
